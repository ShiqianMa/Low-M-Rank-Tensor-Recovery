%==========================================================================
% This script compares various tensor Robust PCA methods
% listed as follows:
%   1. KBR-rpca
%   2. tensor-SVD-based rpca method (t-SVD)
%   3. M-rank-rpca
%   4. Ho-rpca
%
% You can:
%       1. Select competing methods by turn on/off the enable-bits
%
%
% more detail can be found in [1]
% [1] Bo Jiang, Shiqian Ma, Shuzhong Zhang. 
%     Low-M-Rank Tensor Completion and Robust Tensor PCA, submitted to  
%     IEEE Journal of Selected Topics in Signal Processing, 2018.
%
% by Bo Jiang 
% 07/22/2018
%==========================================================================
clc;
clear;close all;
addpath(genpath('algorithms'));


%% Set enable bits
EN_KBR_rpca   = 1; % set to 0 for turning off;
EN_t_SVD    = 1;
EN_M_Rank   = 1;
EN_Ho_rpca    = 1;

%% initial Data
methodname  = {'KBR-rpca','t-SVD','M-Rank','Ho-rpca'};
Mnum   = length(methodname);
p=10; q=10; u=10; v=10;
rCP=4; % rCP is the CP rank of the low rank part of the tensor.
card = round(0.05*p*q*u*v);
T=zeros(p,q,u,v);


for j=1:rCP
    V1=randn(p,1);
    V2=randn(q,1);
    V3=randn(u,1);
    V4=randn(v,1);
    T=T+VectorToTensor(V1,V2,V3,V4,p,q,u,v);
end
maxT = max(T(:));
minT = min(T(:));
T = (T-minT)/(maxT-minT);  % 

Xs=TensorToMatrix(T,p,q,u,v); 
m=p*q;
n=u*v;
Ys = zeros(m,n); tmp = randperm(m*n); tmp = tmp(1:card);
Ys(tmp) = (rand(card,1)-0.5);
Ys_T = MatrixToTensor(Ys, p,q,u,v);
D = Xs + Ys;
TenD = MatrixToTensor(D, p,q,u,v);

% T            = normalized(T);
% T_M = TensorToMatrix(T,p,q,u,v);
% sizeD        = size(D);
% ndim         = length(sizeD);

%% initialization of the parameters
alpha   = ones(1, 3);
alpha   = alpha / sum(alpha);
maxIter = 1000;
epsilon = 1e-5;
mu      = 1e-2; 


i = 0;
%% Use KBR_rpca
i = i+1;
if EN_KBR_rpca
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    sizeD     = size(TenD);
    beta           = 2.5*sqrt(max(sizeD));
    gamma          = beta*100;
    Par.maxIter    = 1000;
    Par.lambda     = 0.1;
    Par.mu         = mu*1000;
    Par.tol        = 1e-5;
    Par.rho        = 1.05;

    [L_KBR, S_KBR] =   KBR_RPCA(TenD,beta,gamma,Par);
    Time(i) = toc;
    
    Sparerror{i} = norm(S_KBR(:)-Ys_T(:))/norm(Ys_T(:));
    Lowrerror{i} = norm(L_KBR(:)-TenD(:))/norm(TenD(:));
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror{i}), '  Low Error: ' num2str(Lowrerror{i}), '.'])
    disp('...')
end


%% Use t_SVD
i = i+1;
if EN_t_SVD
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    [L_t_SVD, S_t_SVD] =   tensor_rpca( TenD , .03/sqrt(size(TenD,1)));
    Time(i) = toc;
    Sparerror{i} = norm(S_t_SVD(:)-Ys_T(:))/norm(Ys_T(:));
    Lowrerror{i} = norm(L_t_SVD(:)-TenD(:))/norm(TenD(:));
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror{i}), '  Low Error: ' num2str(Lowrerror{i}), '.'])
    disp('...')
end

%% Use M_Rank
i = i+1;
if EN_M_Rank
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    
    % Set parameters
    n1 = m; n2 = n;
    opts.D = D;
    opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/10;

    opts.Xs = Xs;  opts.Ys = Ys;
    opts.n1 = n1; opts.n2 = n2;
    opts.sigma = 1e-6; opts.maxitr = 2000; opts.rho = 1*(1/sqrt(n1)); % opts.rho = 2*opts.rho; 
    opts.eta_mu = 2/3; opts.eta_sigma = 2/3; %opts.eta_mu = 8/9;
    opts.muf = 1e-6;
    opts.sigmaf = 1e-6;
    opts.epsilon = 1e-6;
    opts.sv = 100;
    out_ALM = sparse_low_rank_decomp_ALM_SADAL_smoothed(opts.D,opts); % Call ALM to solve the problem
    Time(i) = toc;
    Sparerror{i} = norm(out_ALM.Y - Ys)/norm(Ys);
    Lowrerror{i} = norm(out_ALM.X - Xs)/norm(Xs);
    
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror{i}), '  Low Error: ' num2str(Lowrerror{i}), '.'])
    disp('...')
%     enList = [enList,i];
end


%% Use Ho_rpca
i = i+1;
if EN_Ho_rpca
    tic;
    params.X0 = tenzeros( size(T) );
    N = ndims(T);
    params.V0 = cell( 1, N );
    for i = 1:N
         params.V0{i} = tenzeros( size(T) );
    end
    params.E0 = tenzeros( size(T) );
    params.mu1 = 0.01;
    params.max_iter = 2000;
    params.opt_tol = 1e-5;  %1e-5 for syn data analysis plots, 1e-3 for others
    params.eta = 1/(N+1);

    r = 1/sqrt( max(size(T)) ); %0.015; %0.09:-0.005:0.02;
    lambdaS = 1;
    rRatio = 1/4;
    params.lambdaS = lambdaS;     %1e1;
    params.lambda = params.lambdaS*r*rRatio;       %params.lambdaS*r/4;
    % params.lambda = 0.06;
    params.rRatio = rRatio;
    data.T = tensor(TenD);
    data.X = tensor(T);

    results = tensor_rpca_adal2( data, params );
    Time(i) = toc;
    E_T = double(results.E);
    Sparerror{i} = norm(E_T(:)-Ys_T(:))/norm(Ys_T(:));
    Lowrerror{i} = results.rel_err;
    
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror{i}), '  Low Error: ' num2str(Lowrerror{i}), '.'])
    disp('...')
%     enList = [enList,i];
end


% % Show result
% fprintf('\n');
% fprintf('================== Result =====================\n');
% for i = 1:length(enList)
%     fprintf(' method: %8.8s    Relative Error:  %5.3f     Run Time: %5.3f    \n',...
%         methodname{enList(i)}, rerror{enList(i)}, Time{enList(i)});
% end
% fprintf('================== Result =====================\n');
