%==========================================================================
% This script compares various tensor Robust PCA methods
% listed as follows:
%   1. KBR-rpca
%   2. tensor-SVD-based rpca method (t-SVD)
%   3. M-rank-rpca
%   4. Ho-rpca
%
% You can:
%
%
% more detail can be found in [1]
% [1] Bo Jiang, Shiqian Ma, Shuzhong Zhang. 
%     Low-M-Rank Tensor Completion and Robust Tensor PCA, submitted to  
%     IEEE Journal of Selected Topics in Signal Processing, 2018.
%
% by Bo Jiang 
% 07/22/2018
%==========================================================================
clc;
clear;close all;
addpath(genpath('algorithms'));


%% Set enable bits
EN_KBR_rpca   = 1; % set to 0 for turning off;
EN_t_SVD    = 1;
EN_M_Rank   = 1;
EN_Ho_rpca    = 1;

%% initial Data
methodname  = {'Ho-rpca','M-Rank','KBR-rpca','t-SVD'};
Mnum   = length(methodname);
p=20; q=20; u=20; v=20;
rCP=24; % rCP is the CP rank of the low rank part of the tensor.
card = round(0.05*p*q*u*v);
instnum = 20;
Sparerror = zeros(instnum,Mnum);
Lowrerror = zeros(instnum,Mnum);
Time = zeros(instnum,Mnum);
for inst = 1: instnum
T=zeros(p,q,u,v);
    
  for j=1:rCP
    V1=randn(p,1);
    V2=randn(q,1);
    V3=randn(u,1);
    V4=randn(v,1);
    T=T+VectorToTensor(V1,V2,V3,V4,p,q,u,v);
  end
maxT = max(T(:));
minT = min(T(:));
T = (T-minT)/(maxT-minT);   

Xs=TensorToMatrix(T,p,q,u,v); 
m=p*q;
n=u*v;
Ys = zeros(m,n); tmp = randperm(m*n); tmp = tmp(1:card);
Ys(tmp) = (rand(card,1)-0.5);
Ys_T = MatrixToTensor(Ys, p,q,u,v);
D = Xs + Ys;
TenD = MatrixToTensor(D, p,q,u,v);

%% initialization of the parameters
alpha   = ones(1, 3);
alpha   = alpha / sum(alpha);
maxIter = 1000;
epsilon = 1e-5;
mu      = 1e-2; 


i = 0;
%% Use Ho_rpca
i = i+1;
if EN_Ho_rpca
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    params.X0 = tenzeros( size(T) );
    N = ndims(T);
    params.V0 = cell( 1, N );
    for j = 1:N
         params.V0{j} = tenzeros( size(T) );
    end
    params.E0 = tenzeros( size(T) );
    params.mu1 = 0.01;
    params.max_iter = 2000;
    params.opt_tol = 1e-5;  %1e-5 for syn data analysis plots, 1e-3 for others
    params.eta = 1/(N+1);

    r = 1/sqrt( max(size(T)) ); %0.015; %0.09:-0.005:0.02;
    lambdaS = 1;
    rRatio = 1/4;
    params.lambdaS = lambdaS;     %1e1;
    params.lambda = params.lambdaS*r*rRatio;       %params.lambdaS*r/4;
    % params.lambda = 0.06;
    params.rRatio = rRatio;
    data.T = tensor(TenD);
    data.X = tensor(T);

    results = tensor_rpca_adal2( data, params );
    Time(inst,i) = toc;
    E_T = double(results.E);
    Sparerror(inst,i) = norm(E_T(:)-Ys_T(:))/norm(Ys_T(:));
    Lowrerror(inst,i) = results.rel_err;
    
    disp([methodname{i}, ' done in ' num2str(Time(inst,i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror(inst,i)), '  Low Error: ' num2str(Lowrerror(inst,i)), '.'])
    disp('...')

end

%% Use M_Rank
i = i+1;
if EN_M_Rank
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    
    % Set parameters
    n1 = m; n2 = n;
    opts.D = D;
    opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/10;

    opts.Xs = Xs;  opts.Ys = Ys;
    opts.n1 = n1; opts.n2 = n2;
    opts.sigma = 1e-6; opts.maxitr = 2000; opts.rho = 1*(1/sqrt(n1)); % opts.rho = 2*opts.rho; 
    opts.eta_mu = 2/3; opts.eta_sigma = 2/3; %opts.eta_mu = 8/9;
    opts.muf = 1e-6;
    opts.sigmaf = 1e-6;
    opts.epsilon = 1e-6;
    opts.sv = 100;
    out_ALM = sparse_low_rank_decomp_ALM_SADAL_smoothed(opts.D,opts); % Call ALM to solve the problem
    Time(inst,i) = toc;
    Sparerror(inst,i) = norm(out_ALM.Y - Ys)/norm(Ys);
    Lowrerror(inst,i) = norm(out_ALM.X - Xs)/norm(Xs);
    
    disp([methodname{i}, ' done in ' num2str(Time(inst,i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror(inst,i)), '  Low Error: ' num2str(Lowrerror(inst,i)), '.'])
    disp('...')
end

%% Use KBR_rpca
i = i+1;
if EN_KBR_rpca
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    sizeD     = size(TenD);
    beta           = 2.5*sqrt(max(sizeD));
    gamma          = beta*100;
    Par.maxIter    = 1000;
    Par.lambda     = 0.1;
    Par.mu         = mu*1000;
    Par.tol        = 1e-5;
    Par.rho        = 1.05;

    [L_KBR, S_KBR] =   KBR_RPCA(TenD,beta,gamma,Par);
    Time(inst,i) = toc;
    
    Sparerror(inst,i) = norm(S_KBR(:)-Ys_T(:))/norm(Ys_T(:));
    Lowrerror(inst,i) = norm(L_KBR(:)-TenD(:))/norm(TenD(:));
    disp([methodname{i}, ' done in ' num2str(Time(inst,i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror(inst,i)), '  Low Error: ' num2str(Lowrerror(inst,i)), '.'])
    disp('...')
end

%% Use t_SVD
i = i+1;
if EN_t_SVD
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    [L_t_SVD, S_t_SVD] =   tensor_rpca( TenD , .03/sqrt(size(TenD,1)));
    Time(inst,i) = toc;
    Sparerror(inst,i) = norm(S_t_SVD(:)-Ys_T(:))/norm(Ys_T(:));
    Lowrerror(inst,i) = norm(L_t_SVD(:)-TenD(:))/norm(TenD(:));
    disp([methodname{i}, ' done in ' num2str(Time(inst,i)), ' s.'])
    disp([methodname{i}, ' Sparse Error: ' num2str(Sparerror(inst,i)), '  Low Error: ' num2str(Lowrerror(inst,i)), '.'])
    disp('...')
end
    
end

averSparerror = mean(Sparerror,1);
averLowrerror = mean(Lowrerror,1);
averTime = mean(Time,1);

fprintf('%3.2e & %3.2e & %3.2f & %3.2e & %3.2e & %3.2f & %3.2e & %3.2e & %3.2f & %3.2e & %3.2e & %3.2f \n  ',averSparerror(1),averLowrerror(1), averTime(1), averSparerror(2),averLowrerror(2), averTime(2),averSparerror(3),averLowrerror(3), averTime(3),averSparerror(4),averLowrerror(4), averTime(4));
