%==========================================================================
% This script compares various tensor completion methods for randomly generated low CP-rank tensors.
% listed as follows:
%   1. KBR-TC
%   2. tensor-SVD-based TC method (t-SVD)
%   3. M-rank
%   4. Ho-TC

% You can:
%       1. Change sampling rate by modifying variables  'sample_ratio '
%       2. Select competing methods by turn on/off the enable-bits
%
%
% more detail can be found in [1]
% [1] Bo Jiang, Shiqian Ma, Shuzhong Zhang. 
%     Low-M-Rank Tensor Completion and Robust Tensor PCA, submitted to  
%     IEEE Journal of Selected Topics in Signal Processing, 2018.
%
% by Bo Jiang 
% 07/22/2018
%==========================================================================
clc; clear all; close all;
addpath(genpath('algorithms'));


%% Set enable bits
sample_ratio = 0.3; % sampling ratio;  % higher sigma_ratio <--> heavier Gaussian noise
fprintf( '=== The sampling ratio is %0.2f === \n',sample_ratio); 
EN_KBR_TC   = 1;% set to 0 for turning off;
EN_t_SVD    = 1;
EN_M_Rank   = 1;
EN_Ho_TC    = 1;

%% initial Data
methodname  = {'KBR-TC','t-SVD','M-Rank','Ho-TC'};
Mnum   = length(methodname);
p=10; q=10; u=10; v=10; r = 12; % r is the rank of the matrix M to be completed.
% p=10; q=10; u=13; v=13; r = 15; 
% p=20; q=20; u=20; v=20; r = 24; 
% p=20; q=20; u=25; v=25; r = 28; 
% p=30; q=30; u=30; v=30; r = 35; 
% p=35; q=35; u=40; v=40; r = 45; 

fprintf('==== p=%d, q=%d, u=%d, v=%d, r=%d========\n',p,q,u,v,r); 
instnum = 20;
% Sparerror = zeros(instnum,Mnum);
Lowrerror = zeros(instnum,Mnum);
succ = zeros(instnum,Mnum); succ_tol = 1e-3;
Time = zeros(instnum,Mnum);
for inst = 1: instnum

    fprintf('running the %d-th instance\n', inst)
    
T=zeros(p,q,u,v);
for j=1:r
%     V1=randn(p,1)+1i*randn(p,1);
%     V2=randn(q,1)+1i*randn(q,1);
%     V3=randn(u,1)+1i*randn(u,1);
%     V4=randn(v,1)+1i*randn(v,1);
    V1=randn(p,1);
    V2=randn(q,1);
    V3=randn(u,1);
    V4=randn(v,1);
    T=T+VectorToTensor(V1,V2,V3,V4,p,q,u,v);
end

T_M = TensorToMatrix(T,p,q,u,v);
sizeT        = size(T);
ndim         = length(sizeT);
maxT = max(T(:));
minT = min(T(:));
T_Normalized  = (T-minT)/(maxT-minT);

%% initialization of the parameters
alpha   = ones(1, 3);
alpha   = alpha / sum(alpha);
maxIter = 1000;
epsilon = 1e-5;
beta    = 1e-2; %for the ||_{*}||_{*}||_{*}

%%  sampling with random position
Omega     = zeros(sizeT);
ind       = randperm(prod(sizeT));
known     = ind(1:floor(prod(sizeT)*sample_ratio));
Omega(known) = 1;
% size(Omega)
Omega     = (Omega > 0);
% size(Omega)
T_miss = T_Normalized;
T_miss(~Omega) = mean(T_Normalized(Omega));
enList = [];
m = p*q;
n = u*v;

i = 0;
%% Use KBR_TC
i = i+1;
if EN_KBR_TC
    disp(['performing ',methodname{i}, ' ... ' ]);
    tic;
    Par2.tol     = epsilon;
    Par2.maxIter = maxIter;
    Par2.maxSubiter = 1;%lambda
    Par2.rho = 1.05;
    Par2.mu = beta*1e-3;
    Par2.lambda = 0.1; % 0.01 is even better
    [Re_Tensor{i},CoreT,Beses] = KBR_TC(T_Normalized.*Omega, Omega, Par2);
    Time(i) = toc; 
    Time(inst,i) = Time(i);
%     Re_Tensor{i} = (maxT-minT)*Re_Tensor{i}+minT;
%     rerror{i}=norm(Re_Tensor{i}(:)-T(:))/norm(T(:));
    rerror{i}=norm(Re_Tensor{i}(:)-T_Normalized(:))/norm(T_Normalized(:));
    Lowrerror(inst,i) = rerror{i}; 
    if rerror{i} < succ_tol 
        succ(inst,i) = succ(inst,i)+1;
    end
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Relative Error: ' num2str(rerror{i}), ' .'])
    disp('...')
    enList = [enList,i];
end


%% Use t_SVD
i = i+1;
if EN_t_SVD
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
     normalize              =        max(T_miss(:))                ;
        inX                    =        T_miss/normalize              ;
        gamma                  =        1                             ;
        maxItr                 =        maxIter                       ; % maximum iteration
        rho                    =        0.01                          ;
        myNorm                 =        'tSVD_1'                      ; % dont change for now
        A                      =        diag(sparse(double(Omega(:)))); % sampling operator
        b                      =        A * inX(:)                    ; % available data
        Re_Tensor{i}    =    tensor_cpl_admm( A , b , rho , gamma , ...
            sizeT , maxItr , myNorm , 1 );
        Re_Tensor{i}                   =        Re_Tensor{i} * normalize    ;
        Re_Tensor{i}                   =        reshape(Re_Tensor{i},sizeT) ;  
    Time(i) = toc; 
    Time(inst,i) = Time(i);
%     Re_Tensor{i} = (maxT-minT)*Re_Tensor{i}+minT;
%     rerror{i}=norm(Re_Tensor{i}(:)-T(:))/norm(T(:));
    rerror{i}=norm(Re_Tensor{i}(:)-T_Normalized(:))/norm(T_Normalized(:));
    Lowrerror(inst,i) = rerror{i}; 
    if rerror{i} < succ_tol 
        succ(inst,i) = succ(inst,i)+1;
    end
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Relative Error: ' num2str(rerror{i}), ' .'])
    disp('...')
    enList = [enList,i];
end

%% Use M_Rank
i = i+1;
if EN_M_Rank
    disp(['performing ',methodname{i}, ' ... ']);
    tic;
    rp = round(m*n*sample_ratio); 
    fr = r*(m+n-r)/rp; maxr = floor(((m+n)-sqrt((m+n)^2-4*rp))/2);
    A = known; % A gives the position of samplings
    b = reshape(T_M,m*n,1); b = b(known); % b is the samples from xs
%     opts = get_opts_FPCA(T_M,maxr,m,n,sample_ratio,fr); % get parameters for FPCA . 
if sample_ratio <= 0.5*fr || fr >= 0.38
    hard = 1;
    %fprintf('This is a "hard" problem! \n\n');
else
    hard = 0;
    %fprintf('This is an "easy" problem! \n\n');
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if hard && max(m,n) < 1000
    opts.mu = 1e-8; % final mu
    opts.xtol = 1e-6; % tolerance for subproblems in continuation
    opts.maxinneriter = 500; % maximum iteration number for subproblems in continuation
    opts.tau = 1; % stepsize
else
    opts.mu = 1e-4;
    opts.xtol = 1e-4;
    opts.maxinneriter = 10;
    opts.tau = 2;
end
    opts.xs = T_M;  % true solution xs is given
    opts.fastsvd_ratio_leading = 1e-2; % ratio for computing the hard thresholding, i.e., the rank for next iteration
    opts.mxitr = 1e+5; % maximum iteration number for the outer loop
    opts.eta = 1/4; % ratio to decrease mu in continuation
    opts.maxr = maxr; % maximum rank r is given 
    Out = FPCA_MatComp(m,n,A,b,opts); % call FPCA to solve the matrix completion problem
    Time(i) = toc;
    Time(inst,i) = Time(i);
%     Re_Tensor{i} = (maxT-minT)*Re_Tensor{i}+minT;
%     rerror{i}=norm(Re_Tensor{i}(:)-T(:))/norm(T(:));
%     rerror{i}=norm(Re_Tensor{i}(:)-T_Normalized(:))/norm(T_Normalized(:));
    Re_Tensor{i} = MatrixToTensor(Out.x,p,q,u,v);
    rerror{i}=norm(Re_Tensor{i}(:)-T(:))/norm(T(:));    
    Lowrerror(inst,i) = rerror{i}; 
    if rerror{i} < succ_tol 
        succ(inst,i) = succ(inst,i)+1;
    end
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Relative Error: ' num2str(rerror{i}), ' .'])
    disp('...')
    enList = [enList,i];
end


%% Use Ho_TC
i = i+1;
if EN_Ho_TC
    disp(['performing ',methodname{i}, ' ... ']);
    tic;

    data.Omega = known;
    data.b = T(known); % b is the samples from xs
    data.X = tensor( T );
    N = length( size(data.X) );
    data.Lamb = cell(1,N);
     for i = 1:N
         data.Lamb{i} = tenzeros( size(data.X) );
     end
    data.Lambda = tenzeros( size(data.X) );

    params.mu0 = 3;
    params.max_iter = 2000;
    params.opt_tol = 1e-5;


    results = TC_ADAL_Bo( data, params );
    Re_Tensor{i} = double(results.X);
    Time(i) = toc; 
    Time(inst,i) = Time(i);
    rerror{i}=norm(Re_Tensor{i}(:)-T(:))/norm(T(:));
    Lowrerror(inst,i) = rerror{i}; 
    if rerror{i} < succ_tol 
        succ(inst,i) = succ(inst,i)+1;
    end    
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' Relative Error: ' num2str(rerror{i}), ' .'])
    disp('...')
    enList = [enList,i];
end

end 

% averSparerror = mean(Sparerror,1);
averLowrerror = mean(Lowrerror,1);
averTime = mean(Time,1);

fprintf('%3.2e & %3.2f & %3.2e & %3.2f & %3.2e & %3.2f & %3.2e & %3.2f \n  ',averLowrerror(4), averTime(4),averLowrerror(3), averTime(3),averLowrerror(1), averTime(1),averLowrerror(2), averTime(2));
