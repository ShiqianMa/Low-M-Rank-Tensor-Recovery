clear all
clc

p=30;q=30;u=40;v=40;

r=15;

card = round(0.05*p*q*u*v);


for instnum=1:10

% randn('state',0); rand('state',0);
% addpath('C:\Mywork\Optimization\work\code\ADM\Sparse_LowRank_Mat\Matdata');

%% get data 
T=zeros(p,q,u,v);

for j=1:r
    V1=randn(p,1)+1i*randn(p,1);
    V2=randn(q,1)+1i*randn(q,1);
    V3=randn(u,1)+1i*randn(u,1);
    V4=randn(v,1)+1i*randn(v,1);
    T=T+VectorToTensor(V1,V2,V3,V4,p,q,u,v);
end

Xs=TensorToMatrix(T,p,q,u,v); 
m=p*q;
n=u*v;
Ys = zeros(m,n); tmp = randperm(m*n); tmp = tmp(1:card);
Ys(tmp) = (rand(card,1)-0.5) + (1i*rand(card,1) - 0.5 );
D = Xs + Ys;
n1 = m; n2 = n;
opts.D = D;
opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/10;

opts.Xs = Xs;  opts.Ys = Ys;
opts.n1 = n1; opts.n2 = n2;
opts.sigma = 1e-6; opts.maxitr = 500; opts.rho = 1*(1/sqrt(n1)); % opts.rho = 2*opts.rho; 
opts.eta_mu = 2/3; opts.eta_sigma = 2/3; %opts.eta_mu = 8/9;
opts.muf = 1e-6;
opts.sigmaf = 1e-6;
opts.epsilon = 1e-6;
opts.sv = 100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Call ALM to solve the problem
tic; out_ALM = sparse_low_rank_decomp_ALM_SADAL_smoothed(opts.D,opts); time_ALM = toc;
fprintf('*******************************************************************\n');
%%%%%%%%% print stats %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Sig=svd(out_ALM.X);
I1=find(abs(Sig)>0.0001*max(Sig));
L1=length(I1);

RecT1 = MatrixToTensor(out_ALM.X,p,q,u,v);
RecT2 = permute(RecT1,[1,3,2,4]);
RecT3 = permute(RecT1,[1,4,3,2]);
M2 = TensorToMatrix(RecT2,p,u,q,v);
M3 = TensorToMatrix(RecT3,p,v,u,q);
Sig2=svd(M2);
Sig3=svd(M3);
I2=find(abs(Sig2)>0.0001*max(Sig2));
L2=length(I2);
I3=find(abs(Sig3)>0.0001*max(Sig3));
L3=length(I3);
L = min([L1,L2,L3]);



SI=find(abs(out_ALM.Y)>0.0001);
SL=length(SI);

fprintf('*******************************************************************\n');
fprintf('%d & %d & %d & %3.2e & %3.2f & %d & %d \n', ... 
    instnum,r,card, out_ALM.StopCrit, time_ALM,L,SL);

end

