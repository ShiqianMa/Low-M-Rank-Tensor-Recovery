function opts = getdata(dataformat)

if strcmp(dataformat,'rand-RPCA-1')
    %%% DATA: from paper by Lin et.al.
    % "Fast convex optimization algorithms for exact recovery of a corrupted low-rank matrix"
    m = 100; n = m; r = round(0.05*m); card = round(0.1*m*n);
    Xs = randn(m,r)*randn(r,n);
    Ys = zeros(m,n);
    tmp = randperm(m*n);
    tmp = tmp(1:card);
    Ys(tmp) = 1000*(rand(card,1)-0.5);
    D = Xs + Ys;
    n1 = m; n2 = n;
    opts.D = D;
    opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/1.25;

    %     opts.mu = 1e+1; opts.sigma = 1e-6; opts.rho = 1/sqrt(m); opts.maxitr = 125;
    %     opts.eta_mu = 0.25; opts.eta_sigma = 0.25;
    %     opts.muf = 1e-6; opts.sigmaf = 1e-6;

elseif strcmp(dataformat,'rand-RPCA-2')
    %%%% Random data: from paper by Candes et.al.
    %                   "Robust PCA? "
    m = 100; n = m; r = round(0.02*n); card = round(0.02*m*n);
    Xs = 1/n * randn(m,r) * randn(r,n);
    Ys = zeros(m,n); tmp = randperm(m*n); tmp = tmp(1:card);
    Ys(tmp) = sign(rand(card,1) - 0.5);
    D = Xs + Ys;
    n1 = m; n2 = n;
    opts.D = D;
    opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/1.25;
    %     opts.mu = 1e-2;
    %     opts.mu = norm(D)/0.5; % opts.mu = norm(D)/1.25;
elseif strcmp(dataformat,'rand-RPCA-2-complex')
    %%%% Random data: from paper by Candes et.al.
    %                   "Robust PCA? "
    m = 100; n = m; r = round(0.05*n); card = round(0.05*m*n);
    i = sqrt(-1); 
    Xl = randn(m,r) + i* randn(m,r); Xr = randn(r,n)+i*randn(r,n); 
    Xs = 1/n * Xl*Xr;
    Ys = zeros(m,n); tmp = randperm(m*n); tmp = tmp(1:card);
%     Ys(tmp) = sign(rand(card,1) - 0.5);
    Ys(tmp) = rand(card,1)+ i*rand(card,1);
    D = Xs + Ys;
    n1 = m; n2 = n;
    opts.D = D;
    opts.Xs = Xs; opts.Ys = Ys; opts.mu = norm(D)/1.25;
elseif strcmp(dataformat,'surveillance-video-Lobby')
    %     load Lobby_SwitchLight_ALL_1000_2545_1546_128_160.mat;
    load Lobby_SwitchLight_ALL_1000_2545_1546_128_160_gray.mat;
    [n1,n2] = size(images); % imn1 = 128; imn2 = 160;
    D = images(:,339:588);
    Xs = D; Ys = D;
    opts.D = D; opts.mu = norm(D)/1.25;

elseif strcmp(dataformat,'surveillance-video-Hall')
    load Hall_airport_1000_1496_497_144_176_gray.mat;
    D = images(:,1:200); [n1,n2] = size(images); % imn1 = 144; imn2 = 176;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'surveillance-video-Campus')
    load Campus_trees_1000_1993_994_128_160_gray.mat;
    %     load Campus_trees_1000_1996_997_128_160_R.mat; DR = images(:,181:500);
    %     load Campus_trees_1000_1995_996_128_160_G.mat; DG = images(:,181:500);
    %     load Campus_trees_1000_1994_995_128_160_B.mat; DB = images(:,181:500);
    %     D = [DR, DG, DB];
    D = images(:,181:500);
    [n1,n2] = size(images); % imn1 = 128; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'surveillance-video-Escalator')
    %     load Escalator_airport_1398_2395_998_130_160.mat;
    load Escalator_airport_1398_2394_997_130_160_gray.mat;
    D = images(:,1:300); [n1,n2] = size(images); % imn1 = 130; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'surveillance-video-Campus-color')
    %     load Campus_trees_1000_1993_994_128_160_gray.mat;
    load Campus_trees_1000_1996_997_128_160_R.mat; DR = images(:,181:500);
    load Campus_trees_1000_1995_996_128_160_G.mat; DG = images(:,181:500);
    load Campus_trees_1000_1994_995_128_160_B.mat; DB = images(:,181:500);
    D = [DR, DG, DB];
    [n1,n2] = size(D); % imn1 = 128; imn2 = 160;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'face-recognition')
    %     load yaleB01_P00_All.mat; D = images; [n1,n2] = size(images); imn1 = 480; imn2 = 640;
    load yaleB01_P00_x101_300_y251_450.mat;
    D = images; [n1,n2] = size(images); % imn1 = 200; imn2 = 200;
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'matrix-completion')
    n1 = 500; rr = 0.05; spr = 0.05; sr = 0.9;
    n2 = n1; r = round(rr*n1); m = round(n1*n2*sr); spar = round(n1*n2*spr);
    Xs = randn(n1,r)*randn(r,n2); Ys = zeros(n1,n2);
    tmp = randperm(n1*n2); Omega = tmp(1:m); Omega_c = tmp(m+1:n1*n2);
    OmegaY = randperm(n1*n2); OmegaY = OmegaY(1:spar);
    Ys(OmegaY) = 1000*(rand(spar,1)-0.5); Ys(Omega_c) = 0;
    D = Xs + Ys; b = D(Omega); opts.b = b; opts.OmegaY = OmegaY; opts.Omega_c = Omega_c; opts.Omega = Omega;
    opts.mu = norm(b)/1.25;
    %     opts.mu = norm(b)*5;
    %     beta = m/(sum(abs(b))); beta = 0.2*beta;
    %     beta = 0.25/mean(abs(b));
    %     opts.mu = 1/beta;
    %     opts.mu = norm(b);
    %     opts.mu = 1000;
elseif strcmp(dataformat,'video-denoising')
    load akiyo_data.mat;
    [n1,n2] = size(akiyo_data);
    noise = zeros(n1,n2); spar = round(n1*n2*0.2);
    picks = randperm(n1*n2); picks = picks(1:spar);
    noise(picks) = 100*randn(spar,1);
    %     akiyo_data = akiyo_data/255;
    %     akiyo_data = imadjust(akiyo_data,[0,255],[0,1]);
    D = akiyo_data + noise;
    %     D = imnoise(akiyo_data,'salt & pepper',0.1);
    opts.D = D; opts.mu = norm(D)/1.25;
    Xs = akiyo_data; Ys = noise;
    imn1 = 144; imn2 = 176; ind = 300;
    figure; imshow(abs((reshape( D(:,ind),imn1,imn2))),[]); axis off;
    figure; imshow(reshape(Xs(:,ind),imn1,imn2),[]); axis off;
    figure; imshow(abs(reshape(Ys(:,ind),imn1,imn2)),[]); axis off;
elseif strcmp(dataformat,'video-denoising-color')
    load akiyo_data_color.mat;
    [n1,n2] = size(akiyo_data_color);
    noise = zeros(n1,n2); spar = round(n1*n2*0.1);
    picks = randperm(n1*n2); picks = picks(1:spar);
    noise(picks) = 0.01*randn(spar,1);
    %     akiyo_data = akiyo_data/255;
    %     akiyo_data = imadjust(akiyo_data,[0,255],[0,1]);
    D = akiyo_data_color/255 + noise;
    %     D = imnoise(akiyo_data,'salt & pepper',0.1);
    opts.D = D; % opts.mu = norm(D)/1.25;
    Xs = akiyo_data; Ys = noise;
    imn1 = 144; imn2 = 176; ind = 300;
    Dshow = zeros(imn1,imn2,3); Dshow(:,:,1) = reshape(D(:,ind),imn1,imn2);
    Dshow(:,:,2) = reshape(D(:,ind+300),imn1,imn2); Dshow(:,:,3) = reshape(D(:,ind+600),imn1,imn2);
    figure; imshow(Dshow);
    %     figure; imshow((reshape( D(:,ind),imn1,imn2)),[]); axis off;
    %     figure; imshow(reshape(Xs(:,ind),imn1,imn2),[]); axis off;
    %     figure; imshow(abs(reshape(Ys(:,ind),imn1,imn2)),[]); axis off;
elseif strcmp(dataformat,'mosquito')
    load mosquito_small.mat;
    D = mosquito_small;
    D0 = D; D0(D0<=5) = 0; D0(D0>5) = 255;
    for i = 1: size(D0,1)
        randi = 100*rand;
        for j = 1: size(D0,2)
            if D0(i,j) == 0
                D0(i,j) = randi;
            end
        end
    end
    %     (D>0) = 255;
    opts.originalD = D;
    %     addbackground = zeros(size(D(:,1)));
    %     for j = 1: size(D,1)
    %         if sum(D(j,:)) == 0
    %             addbackground(j) = 100*rand;
    %         end
    %     end
    %     ind0 = find(D(:,1)==0);
    %     addbackground(ind0) = 100*rand(size(ind0));
    [n1,n2] = size(D); % imn1 = 150; imn2 = 200;
    %     for j =1 :n2
    %         D(:,j) = D(:,j) + addbackground;
    %     end
    %     D(D>255) = 255;
    %     opts.background = D - opts.originalD;
    %     opts.addbackground = addbackground;
    opts.D = D0; opts.mu = norm(D)/1.25; opts.mu = 1e+3; % opts.mu = 1e-5*opts.mu;
    Xs = D; Ys = D;
elseif strcmp(dataformat,'mosquito-original')
    load mosquito_small.mat;
    D = mosquito_small;
    opts.originalD = D;
    [n1,n2] = size(D); % imn1 = 150; imn2 = 200;
    opts.D = D; opts.mu = norm(D)/1.25; 
    Xs = D; Ys = D;
end

opts.Xs = Xs;  opts.Ys = Ys;
opts.n1 = n1; opts.n2 = n2;
% % opts.mu = norm(D)/1.25;
% opts.mu = norm(b)/1.25;
opts.sigma = 1e-6; opts.maxitr = 500; opts.rho = 1/sqrt(n1); % opts.rho = 2*opts.rho; 
opts.eta_mu = 2/3; opts.eta_sigma = 2/3; %opts.eta_mu = 8/9;
% opts.mu = 1e-5; opts.eta_mu = 1; opts.eta_sigma = 1; opts.sigma = 1e-6;
% opts.muf = opts.mu*1e-7;
opts.muf = 1e-6;
opts.sigmaf = 1e-6;
opts.epsilon = 1e-6;
opts.sv = 100;
