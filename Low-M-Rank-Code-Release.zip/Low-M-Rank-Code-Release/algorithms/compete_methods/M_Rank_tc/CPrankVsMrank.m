clear all
clc

p=10; q=10; u=10; v=10;

moderank=zeros(20,4);
mrank=zeros(20,3);

for instnum=1:20
T=zeros(p,q,u,v);


r = 4; 
k = 4;
for i=1:k
  M1 = zeros(p,q);
  M2 = zeros(u,v);
  for j=1:r
      M1 = M1 + (randn(p,1)+1i*randn(p,1))*(randn(q,1)+1i*randn(q,1))';
      M2 = M2 + (randn(u,1)+1i*randn(u,1))*(randn(v,1)+1i*randn(v,1))';
  end
  T = T + MatrixGenTensor(M1,M2,p,q,u,v);
end

% r = 40; % r is the rank of the matrix M to be completed.
% for j=1:r
%     V1=randn(p,1)+1i*randn(p,1);
%     V2=randn(q,1)+1i*randn(q,1);
%     V3=randn(u,1)+1i*randn(u,1);
%     V4=randn(v,1)+1i*randn(v,1);
%     T=T+VectorToTensor(V1,V2,V3,V4,p,q,u,v);
% end



RecT1 = T;
RecT2 = permute(RecT1,[1,3,2,4]);
RecT3 = permute(RecT1,[1,4,3,2]);
M1 = TensorToMatrix(T,p,q,u,v);
M2 = TensorToMatrix(RecT2,p,u,q,v);
M3 = TensorToMatrix(RecT3,p,v,u,q);
Sig1=svd(M1);
Sig2=svd(M2);
Sig3=svd(M3);
I1=find(abs(Sig1)>0.0001);
L1=length(I1);
I2=find(abs(Sig2)>0.0001);
L2=length(I2);
I3=find(abs(Sig3)>0.0001);
L3=length(I3);

RecMod1T = permute(RecT1,[4,2,3,1]);
RecMod2T = permute(RecT1,[1,4,3,2]);
RecMod3T = permute(RecT1,[1,2,4,3]);

RecMod1M = TensorToMod4(RecMod1T,v,q,u,p);
RecMod2M = TensorToMod4(RecMod2T,p,v,u,q);
RecMod3M = TensorToMod4(RecMod3T,p,q,v,u);
RecMod4M = TensorToMod4(RecT1,p,q,u,v);

SigMod1=svd(RecMod1M);
SigMod2=svd(RecMod2M);
SigMod3=svd(RecMod3M);
SigMod4=svd(RecMod4M);
Mod1rank=length(find(abs(SigMod1)>0.0001));
Mod2rank=length(find(abs(SigMod2)>0.0001));
Mod3rank=length(find(abs(SigMod3)>0.0001));
Mod4rank=length(find(abs(SigMod4)>0.0001));

moderank(instnum,1)=Mod1rank;
moderank(instnum,2)=Mod2rank;
moderank(instnum,3)=Mod3rank;
moderank(instnum,4)=Mod4rank;

mrank(instnum,1)=L1;
mrank(instnum,2)=L2;
mrank(instnum,3)=L3;

end

for instnum=1:20
fprintf('%d & (%d,%d,%d,%d) &  (%d,%d,%d) \n  ', instnum, moderank(instnum,1), moderank(instnum,2),moderank(instnum,3),moderank(instnum,4), mrank(instnum,1), mrank(instnum,2), mrank(instnum,3));
end
