function T=MatrixGenTensor(M1,M2,p,q,u,v)

t=zeros(p,q,u,v);

for l=1:v
    for k=1:u
         t(:,:,k,l)=M1*M2(k,l);
    end
end
T=t;