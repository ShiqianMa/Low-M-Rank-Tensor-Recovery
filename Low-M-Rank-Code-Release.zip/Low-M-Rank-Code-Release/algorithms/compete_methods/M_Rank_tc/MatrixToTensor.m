function T=MatrixToTensor(M,p,q,u,v)
t=zeros(p,q,u,v);
% for i=1:n
%     for j=1:m
%         for k=1:u
%             for l=1:v
%                 t(i,j,k,l)=M((i+(j-1)*m),(k+(l-1)*v));
%             end
%         end
%         
%         
%     end
% end

for l=1:v
    for k=1:u
         t(:,:,k,l)=reshape(M(:,(k+(l-1)*u)),p,q);
    end
end
T=t;