clear all
clc

p=20; q=20; u=20; v=20;

cprank=zeros(10,1);
rerror=zeros(10,1);
time=zeros(10,1);
mrank=zeros(10,1);

for instnum=1:10
T=zeros(p,q,u,v);

r = 24; % r is the rank of the matrix M to be completed.
for j=1:r
    V1=randn(p,1)+1i*randn(p,1);
    V2=randn(q,1)+1i*randn(q,1);
    V3=randn(u,1)+1i*randn(u,1);
    V4=randn(v,1)+1i*randn(v,1);
    T=T+VectorToTensor(V1,V2,V3,V4,p,q,u,v);
end



M=TensorToMatrix(T,p,q,u,v); % M is the matrix to be completed

m=p*q;
n=u*v;
sr = 0.30; % sr is the sampling ratio
rp = round(m*n*sr); 


% fr is the freedom of set of rank-r matrix, maxr is the maximum rank one
% can recover with p samples, which is the max rank to keep fr < 1
fr = r*(m+n-r)/rp; maxr = floor(((m+n)-sqrt((m+n)^2-4*rp))/2);

% rs = randseed; randn('state',rs); rand('state',rs);

A = randperm(m*n); A = A(1:rp); % A gives the position of samplings
b = reshape(M,m*n,1); b = b(A); % b is the samples from xs

% get parameters for FPCA . 
opts = get_opts_FPCA(M,maxr,m,n,sr,fr); 

% call FPCA to solve the matrix completion problem
fprintf('solving by FPCA....\n');
solve_fpc = cputime;
Out = FPCA_MatComp(m,n,A,b,opts);
solve_fpc = cputime - solve_fpc; Out.solve_t = solve_fpc;
fprintf('done!\n');
Sig=svd(Out.x);
I1=find(abs(Sig)>0.0001*norm(Sig,'fro'));
L1=length(I1);
RecT1 = MatrixToTensor(Out.x,p,q,u,v);
RecT2 = permute(RecT1,[1,3,2,4]);
RecT3 = permute(RecT1,[1,4,3,2]);
M2 = TensorToMatrix(RecT2,p,u,q,v);
M3 = TensorToMatrix(RecT3,p,v,u,q);
Sig2=svd(M2);
Sig3=svd(M3);
I2=find(abs(Sig2)>0.0001*norm(Sig2,'fro'));
L2=length(I2);
I3=find(abs(Sig3)>0.0001*norm(Sig3,'fro'));
L3=length(I3);
Lmin = min([L1,L2,L3]);
Lmax = max([L1,L2,L3]);

% RecMod1T = permute(RecT1,[4,2,3,1]);
% RecMod2T = permute(RecT1,[1,4,3,2]);
% RecMod3T = permute(RecT1,[1,2,4,3]);
% 
% RecMod1M = TensorToMod4(RecMod1T,v,q,u,p);
% RecMod2M = TensorToMod4(RecMod2T,p,v,u,q);
% RecMod3M = TensorToMod4(RecMod3T,p,q,v,u);
% RecMod4M = TensorToMod4(RecT1,p,q,u,v);
% 
% SigMod1=svd(RecMod1M);
% SigMod2=svd(RecMod2M);
% SigMod3=svd(RecMod3M);
% SigMod4=svd(RecMod4M);
% Mod1rank=length(find(abs(SigMod1)>0.0001));
% Mod2rank=length(find(abs(SigMod2)>0.0001));
% Mod3rank=length(find(abs(SigMod3)>0.0001));
% Mod4rank=length(find(abs(SigMod4)>0.0001));

cprank(instnum)=Lmax;
rerror(instnum)=norm(Out.x-M,'fro')/norm(M,'fro');
time(instnum)=solve_fpc;
mrank(instnum)=Lmin;

% print the statistics
% fprintf('m = %d, n = %d, r = %d, rp = %d, samp.ratio = %3.2f, freedom = %3.2f, matrix rank = %d \n',m,n,r,rp,sr,fr,L);
% fprintf('Time = %3.2f, relative error = %3.2e\n', solve_fpc, norm(Out.x-M,'fro')/norm(M,'fro'));
% fprintf('%d & %d & %3.2e & %3.2f & %d \n  ', instnum, r, norm(Out.x-M,'fro')/norm(M,'fro'), solve_fpc, L);
end


fprintf('CP-rank  %d & %3.2e & %3.2f & %d & %d \n  ', r, mean(rerror),  mean(time),cprank(instnum), mrank(instnum));

