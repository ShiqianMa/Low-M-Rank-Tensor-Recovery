function M = TensorToMatrix(T,n,m,u,v)
matr = zeros(n*m,u*v);
for l = 1:v
    for k = 1:u
        matr(:,(k+(l-1)*u)) = reshape(T(:,:,k,l),n*m,1);
    end
end
M = matr;

