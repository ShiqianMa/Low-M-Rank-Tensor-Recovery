function M = TensorToMod4(T,n,m,u,v)
matr = zeros(n*m*u,v);
for k=1:v
    matr(:,k)=reshape(T(:,:,:,k),n*m*u,1);
end
M = matr;

