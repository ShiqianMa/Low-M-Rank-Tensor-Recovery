function T=VectorToTensor(V1,V2,V3,V4,p,q,u,v)

t=zeros(p,q,u,v);

for l=1:v
    for k=1:u
         t(:,:,k,l)=V1*conj(V2)'*V3(k)*V4(l);
    end
end
T=t;