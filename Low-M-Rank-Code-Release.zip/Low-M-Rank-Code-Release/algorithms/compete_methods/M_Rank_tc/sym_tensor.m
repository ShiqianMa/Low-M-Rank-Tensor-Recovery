%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function sym_tensor(Q).
% Input: d th-order tensor Q\in\R^{n^d}.
% Output: super-symmetric d th-order tensor.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function value = sym_tensor(Q,p,m)

% [p,m]=psort(d);
symQ = zeros(size(Q));
for k = 1:m
    symQ = symQ + permute(Q, p(k,:));
end

value = symQ /m;

